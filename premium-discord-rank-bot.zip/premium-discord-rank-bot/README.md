# Premium Discord Rank Bot

A Discord.js v14 bot for a custom server rank ladder. It supports:

- `/promote member reason` — move one step up.
- `/demote member reason` — move one step down.
- `/setrank member rank reason` — assign an exact configured rank.
- `/rank member` — show the member's current rank.
- `/rank-config add role position` — configure the ladder (1 is lowest).
- `/rank-config remove role`
- `/rank-config list`
- `/rank-config logs channel` and `/rank-config clear-logs`
- Automatic replacement: it adds the new rank, then removes the other configured rank roles.
- Rank-change embeds in a chosen log channel.
- Manager checks and Discord role-hierarchy checks.
- Per-server configuration saved in `data/guild-config.json`.

## 1. Create the Discord application

1. Open https://discord.com/developers/applications
2. Create an application, then open **Bot** and add a bot.
3. Copy the bot token. Keep it private; never post it in Discord or GitHub.
4. Under **Bot → Privileged Gateway Intents**, enable **Server Members Intent**.
5. Under **OAuth2 → URL Generator**, select `bot` and `applications.commands`.
6. Grant only the permissions needed: **Manage Roles**, **View Channels**, **Send Messages**, **Embed Links**. Do not grant Administrator.
7. Use the generated URL to invite it to your server.
8. In Server Settings → Roles, move the bot's role above every rank role it must manage.

## 2. Configure environment variables

Copy `.env.example` to `.env` for local testing and fill in:
- `DISCORD_TOKEN`
- `CLIENT_ID`
- `GUILD_ID` (your server ID; recommended while testing)

Never upload `.env` to GitHub. On Railway, add these values in the service's Variables page instead.

## 3. Run it

Requires Node.js 20 or newer.

```bash
npm install
npm start
```

`npm start` automatically registers the slash commands first, then starts the bot. With `GUILD_ID`, commands register to that server and usually appear quickly. If you leave it blank, commands register globally and can take longer to appear. Use `npm run deploy` only when you want to register command definitions separately.

## 4. Configure your rank ladder

In your Discord server, run `/rank-config add` once for each rank. Use consecutive positions, with **1 as the lowest**.

Example:
- Recruit — position 1
- Member — position 2
- Elite — position 3
- Co-Leader — position 4
- Leader — position 5

Then run `/rank-config list` to verify the order, and `/rank-config logs channel:#rank-logs` to enable logs.

Anyone using `/promote`, `/demote`, or `/setrank` must have **Manage Roles** or **Administrator**. Only members with **Manage Server** or **Administrator** can configure the hierarchy.

## 5. Railway deployment

1. Create a GitHub repository and upload these project files (not `.env`).
2. In Railway, create a new project → Deploy from GitHub Repo.
3. Add `DISCORD_TOKEN`, `CLIENT_ID`, and `GUILD_ID` under Variables.
4. Set the start command to `npm start`.
5. Make sure the service is a continuously running service, not a scheduled job.
6. Keep a persistent volume mounted at `/app/data` so the rank configuration survives redeploys/restarts. If your Railway service uses a different working directory, mount the volume at that service's `data` directory.
7. Deploy. Check the logs for `Online as ...`.

Run `npm run deploy` once whenever you change slash-command definitions. You can run it locally, or use a one-off Railway command if your setup supports it.

## Safety and limitations

- The bot never needs Administrator permission. Grant only Manage Roles and the channel permissions it needs.
- The bot cannot manage roles above or equal to its highest role.
- The bot checks that the person issuing rank changes has Manage Roles or Administrator and cannot modify a member whose highest role is equal to or above theirs (except the server owner).
- The bot adds the destination rank before removing previous configured ranks, so a failed add does not strip the member's existing rank.
- Rank configuration is stored in a JSON file. Use a persistent volume on Railway or the config can be lost when the container is replaced.
- This starter is designed for a single running bot process. Do not run multiple replicas against the same JSON file.
- Test with a spare account and low-risk test roles before using it for real clan ranks.
